from django.shortcuts import render
import requests
import datetime
def index(request):
    api_key = "928564579e96f9109dccd841b2cecaa9"
    current_weather_url = 'https://api.openweathermap.org/data/2.5/weather?q={}&appid={}&units=metric'
    if request.method == 'POST':
        city = request.POST['city1']
        weather_data1 = fetch_weather(city, api_key, current_weather_url)
        context = {
            'weather_data1': weather_data1,
        }
        return render(request, 'weather_app/index.html', context)
    else:
        return render(request, 'weather_app/index.html')

def fetch_weather(city, api_key, current_weather_url):
    response = requests.get(current_weather_url.format(city, api_key)).json()
    weather_data = {
        'name': city,
        'temperature': round(response['main']['temp']),
        'description': response['weather'][0]['description'],
    }
    return weather_data
    